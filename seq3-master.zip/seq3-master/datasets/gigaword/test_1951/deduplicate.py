refs = open("task1_ref0_min8.txt").readlines()
inputs = open("input_min8.txt").readlines()

