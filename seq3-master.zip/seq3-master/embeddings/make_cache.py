from utils.load_embeddings import load_word_vectors

load_word_vectors("GoogleNews-vectors-negative300.txt", 300)
